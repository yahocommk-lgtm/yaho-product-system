# 웹에서 구동/테스트하는 방법 (Streamlit Community Cloud, 무료)

이 폴더(app.py, requirements.txt)를 그대로 사용하면 됩니다. 별도의 서버나
결제 없이, 몇 분이면 `https://내앱이름.streamlit.app` 형태의 공개 URL이 생깁니다.

## 1) GitHub 저장소 만들기
1. https://github.com 에서 새 저장소 생성 (예: `yaho-product-system`), Public 또는 Private 아무거나 가능
2. 이 폴더 안의 파일(app.py, requirements.txt, .gitignore)을 저장소에 업로드
   - GitHub 웹사이트에서 "Add file → Upload files"로 드래그해서 올려도 되고,
   - 로컬에서 git을 쓸 줄 아시면:
     ```bash
     cd yaho-product-system
     git init
     git add app.py requirements.txt .gitignore
     git commit -m "add product automation app"
     git branch -M main
     git remote add origin https://github.com/본인계정/yaho-product-system.git
     git push -u origin main
     ```

## 2) Streamlit Community Cloud에 배포
1. https://share.streamlit.io 접속 → GitHub 계정으로 로그인
2. "New app" 클릭
3. Repository: 방금 만든 저장소 선택
4. Branch: `main`
5. Main file path: `app.py`
6. "Deploy" 클릭

1~2분 정도 빌드가 진행되고, 완료되면 `https://xxxx.streamlit.app` 형태의
공개 URL이 발급됩니다. 이 링크를 팀원들에게 공유하면 브라우저에서 바로
테스트할 수 있습니다.

## 3) 코드 수정 후 재배포
GitHub 저장소에 새로 push하면 Streamlit Cloud가 자동으로 감지해서 앱을
다시 빌드/배포합니다. 별도 조작이 필요 없습니다.

## 참고 — 지금 버전의 한계 (배포 전에 알아두면 좋은 점)
- 데이터가 `st.session_state`(메모리)에만 저장됩니다. 앱이 재시작되거나
  일정 시간 사용이 없어 슬립 상태가 되면(Streamlit Cloud 무료 플랜은 일정
  시간 미접속 시 슬립) 등록했던 상품 목록이 초기화됩니다. 여러 직원이 함께
  쓰는 운영용으로 가려면 DB 연동이 필요합니다(다음 개발 단계).
- "AI 상세페이지 초안" 버튼은 아직 실제 AI 연결 없이 고정 템플릿 문자열을
  생성합니다. 실제 OpenAI API 연동이 필요합니다.
- 로그인/권한 기능이 없어 URL을 아는 사람은 누구나 접근·입력 가능합니다.
  외부에 공유하기 전에 필요하면 간단한 비밀번호 게이트를 추가할 수 있습니다.

## 로컬에서 먼저 테스트하고 싶다면
```bash
pip install -r requirements.txt
streamlit run app.py
```
브라우저가 자동으로 열리며 http://localhost:8501 에서 확인할 수 있습니다.
(제가 이미 이 방식으로 전체 기능 동작을 확인했습니다.)
